package aula.projeto_poo;

public class mainTeste {
    public static void main(String[] args) {
        TecnicoFutsal t = new TecnicoFutsal("Roberto", 26);

        t.exibirPerfil();
    }
}
